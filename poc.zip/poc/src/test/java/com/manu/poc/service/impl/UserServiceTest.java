package com.manu.poc.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.manu.poc.constant.RoleName;
import com.manu.poc.dto.UserDTO;
import com.manu.poc.exceptions.BadRequestException;
import com.manu.poc.helper.UserHelper;
import com.manu.poc.model.User;
import com.manu.poc.repository.UserRepository;
import com.manu.pos.service.UserService;

/**
 * @author Mukesh
 *
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceTest {
	
	private UserDTO userDTO;

	private User user;
	
	private Optional<User> userOptionObj;

	@Autowired
	private UserHelper userHealper;

	@MockBean
	private UserRepository userRepository;

	@Autowired
	private UserService userService;
	
	@Before
	public void setUp() throws Exception {
		userDTO = prepareRequestObject();
		user = userHealper.mapUserDTOtoEntity(userDTO);
	}
	
	@Test
	public void testAddUser() throws BadRequestException {
		doReturn(user).when(userRepository).save(any(User.class));
		userService.addUser(userDTO);
	}

	@Test
	public void testGetUserByUsername() throws BadRequestException {
		userOptionObj = Optional.of(user);
		doReturn(userOptionObj).when(userRepository).findByUsername(any(String.class));
		UserDTO userResponse = userService.getUserByUsername(userDTO.getUsername());
		assertNotNull(userResponse);
		assertEquals(userResponse.getFirstName(), userDTO.getFirstName());
		assertEquals(userResponse.getLastName(), userDTO.getLastName());
		assertEquals(userResponse.getUsername(), userDTO.getUsername());
	}

	@Test
	public void testDeleteUserDetails() {
		doNothing().when(userRepository).delete(any(User.class));
		userService.deleteUserDetails(userDTO);
	}
	
	
	@Test
	public void testGetUsers() {
		List<User> users = new ArrayList<User>();
		user.setRoleName(RoleName.ROLE_USER);
		users.add(user);
		doReturn(users).when(userRepository).findAllByRoleName(any(RoleName.class));

		List<UserDTO> usersDtos = userService.getAllUsers();
		assertNotNull(usersDtos);
		assertEquals(1, usersDtos.size());
		for(UserDTO userDTO : usersDtos) {
			assertEquals(RoleName.ROLE_USER, userDTO.getRoleName());
		}
		
	}
	 
	
	@Test
	public void testGetUsersNegative() {
		when(userRepository.findAll()).thenReturn(null);
		
		List<UserDTO> usersDtos = userService.getAllUsers();
		assertNotNull(usersDtos);
		assertEquals(0, usersDtos.size());
	}
	
	
	@Test
	public void testGetUserById() {
		userOptionObj = Optional.of(user);
		doReturn(userOptionObj).when(userRepository).findById(any(Long.class));
		UserDTO userResponse = userService.findById(userDTO.getId());
		assertNotNull(userResponse);
		assertEquals(userResponse.getId(), userDTO.getId());
		assertEquals(userResponse.getFirstName(), userDTO.getFirstName());
		assertEquals(userResponse.getLastName(), userDTO.getLastName());
		assertEquals(userResponse.getUsername(), userDTO.getUsername());
		
	}
	/**
	 * This method is used to prepare custom dto object
	 * @return
	 */
	private UserDTO prepareRequestObject() {
		UserDTO userDTO = new UserDTO();
		userDTO.setId(1L);
		userDTO.setAge(30);
		userDTO.setPassword("test");
		userDTO.setUsername("mukeshshah");
		userDTO.setFirstName("Mukesh");
		userDTO.setRoleName(RoleName.ROLE_ADMIN);
		return userDTO;
	}
	
	@After
	public void tearDown() throws Exception {
		user = null;
		userDTO = null;
	}
	 

}
