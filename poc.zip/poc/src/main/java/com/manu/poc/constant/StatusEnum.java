package com.manu.poc.constant;
/**
 * @author Mukesh
 *
 */
public enum StatusEnum {
	
	USERNAME_ALREADY_EXIST("101", "Username already exist"),
	INVALID_REQUEST_DATA("102", "Request parameters values is missing"), SUCCESS("200", "Success"),
	USER_NOT_FOUND("103", "User not found"),
	NO_CONTENT("104", "No Content"), UNKNOWN_EXCEPTION("999", "Unknown Exception");

	private String statusCode;
	private String statusMessage;

	private StatusEnum(String statusCode, String statusMessage) {
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @return the statusMessage
	 */
	public String getStatusMessage() {
		return statusMessage;
	}

}
