package com.manu.pos.service;

import java.util.List;

import com.manu.poc.dto.UserDTO;
import com.manu.poc.exceptions.BadRequestException;
/**
 * @author Mukesh
 *
 */
public interface UserService {

	/**
	 * Add new user
	 * 
	 * @param userDTO
	 * @throws BadRequestException
	 */
	void addUser(UserDTO userDTO) throws BadRequestException;

	/**
	 * update user details
	 * 
	 * @param userDTO
	 */
	UserDTO updateUserDetails(UserDTO userDTO) throws BadRequestException;

	/**
	 * Fetch the user details by username
	 * 
	 * @param username
	 * @return
	 */
	UserDTO getUserByUsername(String username) throws BadRequestException;

	/**
	 * Delete the user
	 * 
	 * @param userDTO
	 */
	void deleteUserDetails(UserDTO userDTO);

	/**
	 * This method is used to get all users
	 * 
	 * @return
	 */
	List<UserDTO> getAllUsers();
	
	/**
	 * This method is used to delete user by id
	 * @param id
	 * @return
	 */
	public UserDTO findById(Long id);
}
