package com.manu.poc.dto;

import java.io.Serializable;
/**
 * @author Mukesh
 *
 */
public class ResponseDTO<T> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5677959383340766469L;
	private T results;
	private String statusCode;
	private String statusMessage;

	public ResponseDTO(T results, String statusCode, String statusMessage) {
		this.results = results;
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
	}

	public ResponseDTO(String statusCode, String statusMessage) {
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
	}

	/**
	 * @return the results
	 */
	public T getResults() {
		return results;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @return the statusMessage
	 */
	public String getStatusMessage() {
		return statusMessage;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseDTO [results=");
		builder.append(results);
		builder.append(", statusCode=");
		builder.append(statusCode);
		builder.append(", statusMessage=");
		builder.append(statusMessage);
		builder.append("]");
		return builder.toString();
	}

}
