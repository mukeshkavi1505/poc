package com.manu.poc.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.manu.poc.dto.UserDTO;
import com.manu.poc.model.User;
/**
 * @author Mukesh
 *
 */
@Component
public class UserHelper {

	/**
	 * 
	 * Convert user dto to entity
	 * 
	 * @param userDTO
	 * @return
	 */
	public User mapUserDTOtoEntity(UserDTO userDTO) {
		User user = new User();
		if (userDTO != null)
			BeanUtils.copyProperties(userDTO, user);
		return user;
	}

	/**
	 * 
	 * Convert user entity to dto
	 * 
	 * @param user
	 * @return
	 */
	public UserDTO mapUserEntityToDTO(User user) {
		UserDTO userDTO = new UserDTO();
		if (user != null)
			BeanUtils.copyProperties(user, userDTO);
		return userDTO;
	}

	/**
	 * 
	 * Convert user dtos to entities
	 * 
	 * @param userDTOs
	 * @return
	 */
	public List<User> mapUserDTOstoEntitys(List<UserDTO> userDTOs) {
		List<User> users = new ArrayList<>();
		if (userDTOs != null && !userDTOs.isEmpty())
			users.addAll(userDTOs.stream().map(userDTO -> mapUserDTOtoEntity(userDTO)).collect(Collectors.toList()));
		return users;
	}

	/**
	 * 
	 * Convert user entities to dtos
	 * 
	 * @param users
	 * @return
	 */
	public List<UserDTO> mapUserEntitysToDTOs(List<User> users) {
		List<UserDTO> userDTOs = new ArrayList<>();
		if (users != null && !users.isEmpty())
			userDTOs.addAll(users.stream().map(user -> mapUserEntityToDTO(user)).collect(Collectors.toList()));
		return userDTOs;
	}
	
	
	/**
	 * Update user details from new user object to existing
	 * @param existingUser
	 * @param newUser
	 * @return
	 */
	public User updateUserDetails(User existingUser, UserDTO newUser) {
		if(StringUtils.hasText(newUser.getFirstName())) {
			existingUser.setFirstName(newUser.getFirstName());
		}
		if(StringUtils.hasText(newUser.getLastName())) {
			existingUser.setLastName(newUser.getLastName());
		}
		if(newUser.getAge() > 0) {
			existingUser.setAge(newUser.getAge());
		}
		return existingUser;
	}

}
