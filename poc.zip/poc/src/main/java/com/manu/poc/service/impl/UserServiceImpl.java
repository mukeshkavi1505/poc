package com.manu.poc.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.manu.poc.constant.RoleName;
import com.manu.poc.constant.StatusEnum;
import com.manu.poc.dto.UserDTO;
import com.manu.poc.exceptions.BadRequestException;
import com.manu.poc.helper.UserHelper;
import com.manu.poc.model.User;
import com.manu.poc.repository.UserRepository;
import com.manu.pos.service.UserService;

/**
 * @author Mukesh
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private UserHelper userHelper;

	@Override
	public void addUser(UserDTO userDTO) throws BadRequestException {
		Optional<User> user = userRepository.findByUsername(userDTO.getUsername());
		if (user.isPresent())
			throw new BadRequestException(StatusEnum.USERNAME_ALREADY_EXIST.getStatusCode(),
					StatusEnum.USERNAME_ALREADY_EXIST.getStatusMessage());
		userDTO.setPassword(passwordEncoder.encode(userDTO.getPassword()));
		userRepository.save(userHelper.mapUserDTOtoEntity(userDTO));
	}

	@Override
	public UserDTO getUserByUsername(String username) throws BadRequestException {
		Optional<User> user = userRepository.findByUsername(username);
		if(!user.isPresent()) throw new BadRequestException(StatusEnum.USERNAME_ALREADY_EXIST.getStatusCode(),
				StatusEnum.USERNAME_ALREADY_EXIST.getStatusMessage());
		return userHelper.mapUserEntityToDTO(user.get());
	}

	@Override
	public void deleteUserDetails(UserDTO userDTO) {
		userRepository.delete(userHelper.mapUserDTOtoEntity(userDTO));

	}

	@Override
	public List<UserDTO> getAllUsers() {
		List<User> users = userRepository.findAllByRoleName(RoleName.ROLE_USER);
		return userHelper.mapUserEntitysToDTOs(users);
	}

	@Override
	public UserDTO findById(Long id) {
		Optional<User> user = userRepository.findById(id);
		if (user.isPresent())
			return userHelper.mapUserEntityToDTO(user.get());
		else
			return null;
	}

	@Override
	public UserDTO updateUserDetails(UserDTO userDTO) throws BadRequestException {
		Optional<User> existingUser = userRepository.findByUsername(userDTO.getUsername());
		if (!existingUser.isPresent()) {
			throw new BadRequestException(StatusEnum.USER_NOT_FOUND.getStatusCode(),
					StatusEnum.USER_NOT_FOUND.getStatusMessage());
		}
		User user = userRepository.save(userHelper.updateUserDetails(existingUser.get(), userDTO));
		return userHelper.mapUserEntityToDTO(user);

	}

}
