package com.manu.poc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.manu.poc.constant.RoleName;
import com.manu.poc.constant.StatusEnum;
import com.manu.poc.dto.ResponseDTO;
import com.manu.poc.dto.UserDTO;
import com.manu.poc.exceptions.BadRequestException;
import com.manu.pos.service.UserService;

/**
 * @author Mukesh
 *
 */
@RestController
@RequestMapping("/admin/")
public class AdminController {

	@Autowired
	private UserService userService;

	/**
	 * Save user details.
	 * 
	 * @param userDTO
	 * @return
	 * @throws BadRequestException
	 */
	@PostMapping(value = "add-admin", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDTO<?> addUserDetails(@RequestBody UserDTO userDTO) throws BadRequestException {
		if (userDTO == null || !StringUtils.hasText(userDTO.getUsername())
				|| !StringUtils.hasText(userDTO.getPassword())) {
			throw new BadRequestException(StatusEnum.INVALID_REQUEST_DATA.getStatusCode(),
					StatusEnum.INVALID_REQUEST_DATA.getStatusMessage());
		}
		userDTO.setRoleName(RoleName.ROLE_ADMIN);
		userService.addUser(userDTO);
		return new ResponseDTO<Object>(StatusEnum.SUCCESS.getStatusCode(), StatusEnum.SUCCESS.getStatusMessage());
	}

}
