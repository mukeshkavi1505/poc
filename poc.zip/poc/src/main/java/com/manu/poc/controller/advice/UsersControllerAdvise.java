package com.manu.poc.controller.advice;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.manu.poc.constant.StatusEnum;
import com.manu.poc.dto.ResponseDTO;
import com.manu.poc.exceptions.BadRequestException;

@RestControllerAdvice
public class UsersControllerAdvise {

	private static final Logger logger = LoggerFactory.getLogger(UsersControllerAdvise.class);

	@ExceptionHandler(BadRequestException.class)
	public ResponseDTO<?> handleBadRequest(BadRequestException badRequestException) {
		logger.error("bad request exception", badRequestException);
		return prepareResponse(badRequestException.getStatusCode(), badRequestException.getStatusMessage());
	}

	@ExceptionHandler(SQLException.class)
	public ResponseDTO<?> handleBadRequest(SQLException sqlException) {
		logger.error("SQL  exception", sqlException);
		return prepareResponse(String.valueOf(sqlException.getErrorCode()), sqlException.getMessage());
	}

	@ExceptionHandler(Exception.class)
	public ResponseDTO<?> handleBadRequest(Exception exception) {
		logger.error("unknown  exception", exception);
		return prepareResponse(StatusEnum.UNKNOWN_EXCEPTION.getStatusCode(),
				StatusEnum.UNKNOWN_EXCEPTION.getStatusMessage());
	}

	private ResponseDTO<?> prepareResponse(String statusCode, String statusMessage) {
		return new ResponseDTO<Object>(statusCode, statusMessage);
	}
}
