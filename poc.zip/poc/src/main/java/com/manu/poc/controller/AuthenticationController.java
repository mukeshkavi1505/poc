package com.manu.poc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.manu.poc.constant.StatusEnum;
import com.manu.poc.dto.LoginResponseDTO;
import com.manu.poc.dto.ResponseDTO;
import com.manu.poc.dto.UserDTO;
import com.manu.poc.security.JwtTokenProvider;

/**
 * @author Mukesh
 *
 */
@RestController
@RequestMapping("/auth/")
public class AuthenticationController {

	@Autowired
	private JwtTokenProvider tokenProvider;

	@PostMapping("generateToken")
	public ResponseDTO<?> generateToken(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {
		Authentication authentication = SecurityContextHolder.getContextHolderStrategy().getContext()
				.getAuthentication();
		UserDTO userDTO = (UserDTO) authentication.getPrincipal();
		LoginResponseDTO responseDTO = new LoginResponseDTO();
		responseDTO.setAuthToken(tokenProvider.generateToken(authentication));
		responseDTO.setUsername(userDTO.getUsername());
		return new ResponseDTO<LoginResponseDTO>(responseDTO, StatusEnum.SUCCESS.getStatusCode(),
				StatusEnum.SUCCESS.getStatusMessage());
	}

}
