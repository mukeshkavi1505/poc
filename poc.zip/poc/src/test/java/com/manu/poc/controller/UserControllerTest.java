package com.manu.poc.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.manu.poc.constant.RoleName;
import com.manu.poc.constant.StatusEnum;
import com.manu.poc.dto.ResponseDTO;
import com.manu.poc.dto.UserDTO;
import com.manu.poc.exceptions.BadRequestException;
import com.manu.pos.service.UserService;

/**
 * @author Mukesh
 *
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserControllerTest {

	@Autowired
	private UserController userController;

	@MockBean
	private UserService userService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {

	}

	private UserDTO prepareAddUserRequest() {
		UserDTO dto = new UserDTO();
		dto.setAge(25);
		dto.setFirstName("Test");
		dto.setLastName("case");
		dto.setPassword("test");
		dto.setUsername("test");
		dto.setRoleName(RoleName.ROLE_USER);
		return dto;
	}

	@Test
	public void testAddUserDetails() throws BadRequestException {
		doNothing().when(userService).addUser(any(UserDTO.class));
		ResponseDTO<?> responseDTO = userController.addUserDetails(prepareAddUserRequest());
		assertNotNull(responseDTO);
		assertEquals(StatusEnum.SUCCESS.getStatusMessage(), responseDTO.getStatusMessage());
		assertEquals(StatusEnum.SUCCESS.getStatusCode(), responseDTO.getStatusCode());
	}

	@Test(expected = BadRequestException.class)
	public void testAddUserDetailsWithoutRequestObject() throws BadRequestException {
		doNothing().when(userService).addUser(any(UserDTO.class));
		userController.addUserDetails(null);
	}

	@Test(expected = BadRequestException.class)
	public void testAddUserDetailsWithoutUsername() throws BadRequestException {
		doNothing().when(userService).addUser(any(UserDTO.class));
		UserDTO userDTO = prepareAddUserRequest();
		userDTO.setUsername(null);
		userController.addUserDetails(userDTO);
	}

	@Test(expected = BadRequestException.class)
	public void testAddUserDetailsWithoutPassword() throws BadRequestException {
		doNothing().when(userService).addUser(any(UserDTO.class));
		UserDTO userDTO = prepareAddUserRequest();
		userDTO.setPassword(null);
		userController.addUserDetails(userDTO);
	}
}
