package com.manu.poc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.manu.poc.constant.RoleName;
import com.manu.poc.constant.StatusEnum;
import com.manu.poc.dto.ResponseDTO;
import com.manu.poc.dto.UserDTO;
import com.manu.poc.exceptions.BadRequestException;
import com.manu.pos.service.UserService;

/**
 * @author Mukesh
 *
 */
@RestController
@RequestMapping("/user/")
public class UserController {

	@Autowired
	private UserService userService;

	/**
	 * Save user details.
	 * 
	 * @param userDTO
	 * @return
	 * @throws BadRequestException
	 */
	@PostMapping(value = "add-user", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseDTO<?> addUserDetails(@RequestBody UserDTO userDTO) throws BadRequestException {
		if (userDTO == null || !StringUtils.hasText(userDTO.getUsername())
				|| !StringUtils.hasText(userDTO.getPassword())) {
			throw new BadRequestException(StatusEnum.INVALID_REQUEST_DATA.getStatusCode(),
					StatusEnum.INVALID_REQUEST_DATA.getStatusMessage());
		}
		userDTO.setRoleName(RoleName.ROLE_USER);
		userService.addUser(userDTO);
		return new ResponseDTO<Object>(StatusEnum.SUCCESS.getStatusCode(), StatusEnum.SUCCESS.getStatusMessage());
	}
	
	/**
	 * This method is used to update user
	 * @param currentUser
	 * @return
	 * @throws BadRequestException 
	 */
    @PutMapping(value="/update-user", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDTO<?> updateUserDetails(@RequestBody UserDTO newUser) throws BadRequestException
    {
        userService.updateUserDetails(newUser);
        return new ResponseDTO<Object>(StatusEnum.SUCCESS.getStatusCode(), StatusEnum.SUCCESS.getStatusMessage());
    }
	
	/**
	 * This method is used to fetch user by id
	 * @param id
	 * @return
	 * @throws BadRequestException
	 */
    @GetMapping(value = "userid/{user-id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDTO<?> getUserById(@PathVariable("user-id") long userId) throws BadRequestException {
        UserDTO userDTO = userService.findById(userId);
        if (userDTO == null) {
             throw new BadRequestException(StatusEnum.USER_NOT_FOUND.getStatusCode(), StatusEnum.USER_NOT_FOUND.getStatusMessage());
        }
        return new ResponseDTO<Object>(userDTO, StatusEnum.SUCCESS.getStatusCode(), StatusEnum.SUCCESS.getStatusMessage());
    }
    
	/**
	 * This method is used to fetch user by username
	 * @param id
	 * @return
	 * @throws BadRequestException
	 */
    @GetMapping(value = "username/{user-name}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDTO<?> getUserByUserName(@PathVariable("user-name") String userName) throws BadRequestException {
        UserDTO userDTO = userService.getUserByUsername(userName);
        if (userDTO == null) {
             throw new BadRequestException(StatusEnum.USER_NOT_FOUND.getStatusCode(), StatusEnum.USER_NOT_FOUND.getStatusMessage());
        }
        return new ResponseDTO<Object>(userDTO, StatusEnum.SUCCESS.getStatusCode(), StatusEnum.SUCCESS.getStatusMessage());
    }
    
    /**
     * This method is used to delete user
     * @param id
     * @return
     * @throws BadRequestException 
     */
    @DeleteMapping(value="delete/{user-id}")
    public ResponseDTO<?> deleteUser(@PathVariable("user-id") long userId) throws BadRequestException{
    	UserDTO userDTO = userService.findById(userId);
    	if (userDTO == null) {
    		throw new BadRequestException(StatusEnum.USER_NOT_FOUND.getStatusCode(), StatusEnum.USER_NOT_FOUND.getStatusMessage());
        }
        userService.deleteUserDetails(userDTO);
        return new ResponseDTO<Object>(StatusEnum.SUCCESS.getStatusCode(), StatusEnum.SUCCESS.getStatusMessage());
    }

	/**
	 * This method is used to return all users
	 * 
	 * @return list of users
	 * @throws BadRequestException
	 */
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping(value = "/all-users", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseDTO<Object> getAllUsers() {
		return new ResponseDTO<Object>(userService.getAllUsers(), StatusEnum.SUCCESS.getStatusCode(),
				StatusEnum.SUCCESS.getStatusMessage());
	}

}
