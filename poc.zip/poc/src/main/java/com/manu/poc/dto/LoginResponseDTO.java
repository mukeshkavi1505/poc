package com.manu.poc.dto;

import java.io.Serializable;
/**
 * @author Mukesh
 *
 */
public class LoginResponseDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6359607481110610616L;

	private String authToken;
	private String username;

	/**
	 * @return the authToken
	 */
	public String getAuthToken() {
		return authToken;
	}

	/**
	 * @param authToken the authToken to set
	 */
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LoginResponseDTO [authToken=");
		builder.append(authToken);
		builder.append(", username=");
		builder.append(username);
		builder.append("]");
		return builder.toString();
	}

}
