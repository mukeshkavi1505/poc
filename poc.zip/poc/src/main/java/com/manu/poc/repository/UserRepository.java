package com.manu.poc.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.manu.poc.constant.RoleName;
import com.manu.poc.model.User;
/**
 * @author Mukesh
 *
 */
@Repository
public interface UserRepository extends JpaRepository<User, Serializable> {

	Optional<User> findByUsername(String username);

	List<User> findAllByRoleName(RoleName roleUser);

}
