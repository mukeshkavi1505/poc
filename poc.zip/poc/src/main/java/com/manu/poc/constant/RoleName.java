package com.manu.poc.constant;
/**
 * @author Mukesh
 *
 */
public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
