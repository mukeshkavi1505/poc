package com.manu.poc.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.manu.poc.dto.UserDTO;
import com.manu.poc.model.User;
import com.manu.poc.repository.UserRepository;
/**
 * @author Mukesh
 *
 */
@Service
public class AuthenticationServiceImpl implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Let people login with either username or email
		UserDTO userDTO = new UserDTO();
		Optional<User> user = userRepository.findByUsername(username);
		if (!user.isPresent())
			throw new UsernameNotFoundException("User not found");
		userDTO.setUsername(username);
		userDTO.setPassword(user.get().getPassword());

		List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority(user.get().getRoleName().toString()));
		userDTO.setAuthorities(authorities);
		return userDTO;
	}

}